from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='blog-home'),
    path('teacher/',views.teacher, name='teacher'),
    path('cr/',views.cr, name='cr'),
    path('contact/',views.contact, name='contact'),
    path('jobs/',views.job, name='job'),
    path('question/',views.question, name='question'),
]